/* types/links/anchor_escapement/solve.js
   Scappamento a pendolo: blocca la ruota e la fa avanzare di mezzo passo
   a ogni passaggio dello zero del pendolo, con un piccolo impulso.
*/
function updateEscapements(M) {
  const dt = (typeof M.dt === 'number' && M.dt > 0) ? M.dt : 1/60;
  const g_mm = 9810;                 // mm/s²

  for (const gv of M.escapements || []) {
    const axE = gv.g1.ax;            // asse della ruota di scappamento
    const axA = gv.g2.ax;            // asse dell’ancora / pendolo
    const halfPitch = Math.PI / gv.N;

    // --- AGGIORNAMENTO DINAMICO ---
    // Legge la lunghezza del pendolo in tempo reale dal gear o dal def, seguendo lo slider
    gv.pendLen = gv.g2.pendLen || (gv.g2.def && (gv.g2.def.pendulumLength || gv.g2.def.pendLen)) || gv.def.pendulumLength || 160;

    if (gv.lastTheta === undefined) {
      gv.lastTheta = axA.theta;
      gv.vel = 0;
      gv.state = 'blocked_entry';
      gv.impulse = 0;
    }

    const L = gv.pendLen;
    const omega = Math.sqrt(g_mm / L);
    const damping = 0.05;

    // equazione del pendolo + impulso dallo scappamento
    const alpha = -omega * omega * Math.sin(axA.theta) - damping * gv.vel + gv.impulse;
    gv.vel += alpha * dt;

    // se l’utente sta trascinando l’asse del pendolo, rispettiamo il drag
    const isDragging = M.dragAxis && M.dragAxis.idx === axA.idx;
    if (!isDragging) {
      axA.theta += gv.vel * dt;
    } else {
      gv.vel = (axA.theta - gv.lastTheta) / dt;
    }

    // limite di ampiezza (evita che il pendolo faccia il giro)
    const maxAng = 15 * Math.PI / 180;
    if (axA.theta >  maxAng) { axA.theta =  maxAng; gv.vel = 0; }
    if (axA.theta < -maxAng) { axA.theta = -maxAng; gv.vel = 0; }

    // rilevamento del passaggio per lo zero → avanzamento della ruota
    const releaseWindow = ((gv.def && gv.def.impulseWindow) || 2) * Math.PI / 180;
    let shouldAdvance = false;

    if (gv.state === 'blocked_entry' && gv.lastTheta > releaseWindow && axA.theta <= releaseWindow) {
      shouldAdvance = true;
      gv.state = 'blocked_exit';
    } else if (gv.state === 'blocked_exit' && gv.lastTheta < -releaseWindow && axA.theta >= -releaseWindow) {
      shouldAdvance = true;
      gv.state = 'blocked_entry';
    }

    if (shouldAdvance) {
      axE.theta += halfPitch;                         // avanza di mezzo dente
      gv.impulse = (gv.vel >= 0 ? 1 : -1) * 0.8 * omega; // piccolo impulso al pendolo proporzionale a omega
    } else {
      gv.impulse *= 0.9;                              // decadimento dell’impulso
    }

    gv.lastTheta = axA.theta;
  }
}

Registry.link('anchor_escapement', {
  collection: 'escapements',
  order: { resolve: 20, constraints: 60, afterIntegrate: 10 },

  validate(l, w, { E }) {
    if (!l.driver) E(`${w}: manca "driver" (id della ruota di scappamento)`);
    if (!l.driven) E(`${w}: manca "driven" (id dell’ancora)`);
  },

  resolve(M) {
    for (const l of activeLinks('anchor_escapement')) {
      const g1 = M.gearBy[l.driver];   // escapement wheel (driver)
      const g2 = M.gearBy[l.driven];   // anchor (driven)

      if (!g1) throw new Error(`anchor_escapement: driver "${l.driver}" non trovato`);
      if (!g2) throw new Error(`anchor_escapement: driven "${l.driven}" non trovato`);

      const N = l.teeth || g1.z || (g1.def && (g1.def.teeth || g1.def.z)) || 30;
      const R = g1.r || 30;
      const d = 50;

      g1.escapement = { R, N, d };
      g2.escapement = { R, N, d };
      g1.r = R;

      const pendLen = l.pendulumLength || g2.pendLen || (g2.def && (g2.def.pendulumLength || g2.def.pendLen)) || 160;
      const amplitude = l.amplitude || (g2.def && g2.def.amplitude) || 8;

      M.escapements.push({
        def: l, g1, g2, N, R, d,
        pendLen, amplitude,
        lastTheta: undefined,
        vel: 0,
        state: 'blocked_entry',
        impulse: 0
      });
    }
  },

  constraints(M, push, { unit }) {
    for (const gv of M.escapements) {
      const axE = gv.g1.ax;
      push('anchor_escapement', `bloccato ${gv.g1.id}`, unit(axE.idx), 0, { axisIdx: axE.idx });
    }
  },

  afterIntegrate: M => updateEscapements(M),
  settle:         M => updateEscapements(M)
});